<?php
// custom [row]
vc_add_param('vc_row', array(
    "type"        =>  "dropdown",
    "class"       =>  "hide_in_vc_editor",
    "admin_label" =>  true,
    "heading"     =>  "Row Type",
    "param_name"  =>  "style_width",
    "value"       => array(
        "Full Width" => "full_width",
        "Boxed"      => "boxed"
        )
    )
);
vc_add_param('vc_row', array(
        "type"        =>  "dropdown",
        "class"       =>  "hide_in_vc_editor",
        "admin_label" => true,
        "heading"     => "Background Parallax",
        "param_name"  => "background_parallax",
        "value" => array(
            "No"      => "none",
            "Yes"     => "yes"
            )
    )
);
vc_add_param('vc_row', array(
    "type"          =>  "colorpicker",
    "class"         =>  "hide_in_vc_editor",
    "admin_label"   => true,
    "heading"       => "Overlay Parallax",
    "param_name"    => "overlay_parallax",
    "dependency"    => Array('element' => "background_parallax", 'value' => array('yes'))
    )
);

?>