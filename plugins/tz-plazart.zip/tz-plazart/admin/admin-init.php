<?php
    require_once PLUGIN_SERVER_PATH.'/admin/post-type/function-init.php';
    require_once PLUGIN_SERVER_PATH.'/admin/vc-extension/vc-init.php';
    require_once PLUGIN_SERVER_PATH.'/admin/shortcode/function_shortcode.php';
?>